# Plataforma Inteligente de Gestión de Empleados con IA

Incluye cruce, dashboard, edición, exportación y enriquecimiento de datos.